/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula.pkg2.main;  // Especifica o pacote do programa

import javax.swing.JButton;             // Inclui a biblioteca de Botões 
import javax.swing.JComboBox;           // Inclui a biblioteca de caixas de combinação
import javax.swing.JFrame;              // Inclui a biblioteca de Frames/Janelas
import javax.swing.JLabel;              // Inclui a biblioteca de Labels
import javax.swing.JTextField;          // Inclui a biblioteca de Caixas de texto
import java.awt.event.ActionEvent;      // Inclui a biblioteca de Execução de eventos
import java.awt.event.ActionListener;   // Inclui a biblioteca de Verificação de eventos
import java.sql.CallableStatement;
import java.sql.Connection;             // Inclui a biblioteca de Conexão
import java.sql.PreparedStatement;      // Inclui a biblioteca de preparação de comandos
import java.sql.ResultSet;              // Inclui a biblioteca de Resultados de pesquisas
import java.sql.SQLException;           // Inclui a biblioteca de Erros de processamento
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;         // Inclui a biblioteca de Logins
import java.util.logging.Logger;        // Inclui a biblioteca de Logins
import javax.swing.JOptionPane;         // Inclui a biblioteca de Paineis de mensagens
import javax.swing.JRootPane;           // Inclui a biblioteca de Painel Principal

/**
 *
 * @author internet
 */
public class JaneladeClientes extends JFrame {  // declaração do objeto JanelaClientes derivada da classe JFrame
    
    private conexao Conect = new conexao();     // instancia do objeto de conexão com a base de dados
    private Connection Cnn; // inicialização da variavel de conxão

    private final JLabel lblCodigo; // Criação da label do codigo 
    private final JTextField txtCodigo; // Criação do campo Codigo

    private final JLabel lblNome; // Criação da label do nome
    private final JTextField txtNome; // Criação do campo nome

    private final JLabel lblLogradouro; // Criação da label do Logradouro
    private final JComboBox cmbLograd;  // Criação do campo tipo de endereço
    private final JTextField txtLogradouro; // Criação do campo Codigoouro; 

    private final JLabel lblNumero; // Criação da label do numero
    private final JTextField txtNumero; // Criação do campo numero

    private final JLabel lblBairro; // Criação da label do bairro
    private final JTextField txtBairro; // Criação do campo bairro

    private final JLabel lblCidade;// Criação da label da cidade
    private final JTextField txtCidade; // Criação do campo cidade

    private final JLabel lblUF;// Criação da label da UF
    private final JComboBox cmbUF; // Criação do campo UF

    private final JLabel lblCEP; // Criação da label do CEP
    private final JTextField txtCEP;  //99999-999  // Criação do campo CEP

    private final JButton btnInserir; // Criação do botão inserir/gravar
    private final JButton btnAlterar; // Criação do botão Altereção/cancelamento
    private final JButton btnConsultar; // Criação do botão consutar
    private final JButton btnExcluir; // Criação do botão Exclusão
    private final JButton btnSair; // Criação do botão sair
    
    int OpTipo = 0; // variavel de controle de ação
    String PrevCod = ""; // variavel de controle de codigos
    
    public JaneladeClientes() { // inicio da função construtora
        
        Cnn = Conect.getConexao();  // iniciando a conexão

        this.setSize(500, 250);  // estabelece o tamanho da janela
        this.setTitle("Cadastro de Cliente"); // define o titulo da tela
        this.setLayout(null); // desativa os layouts padrão
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // define que quando esta janela for fechada o programa sera encerrado
        
        lblCodigo = new JLabel("Codigo"); // define a label do codigo
        lblCodigo.setSize(40, 30); // define o tamanho do label
        lblCodigo.setLocation(10, 10); // define a localização do label
        this.add(lblCodigo); // adiciona o label

        txtCodigo = new JTextField(); //inicialização do campo do codigo
        txtCodigo.setSize(100,20);// define o tamanho do campo
        txtCodigo.setLocation(105,15);// define a localização do campo
        this.add(txtCodigo);// adiciona o Campo
        
        lblNome = new JLabel ("Nome"); // define a label do nome
        lblNome.setSize(100, 30);// define o tamanho do label
        lblNome.setLocation(10, 40);// define a localização do label
        this.add(lblNome);// adiciona o label

        txtNome = new JTextField ();//inicialização do campo do nome
        txtNome.setSize(350,20);// define o tamanho do campo
        txtNome.setLocation(105,45);// define a localização do campo
        this.add(txtNome);// adiciona o Campo
        
        lblLogradouro = new JLabel ("Logradouro"); // define a label do logradouro
        lblLogradouro.setSize(100, 30);// define o tamanho do label
        lblLogradouro.setLocation(10, 70);// define a localização do label
        this.add(lblLogradouro);// adiciona o label

        cmbLograd = new JComboBox();//inicialização do campo do tipo de logradouro
        cmbLograd.addItem("  "); // adiciona a primeira opção
        cmbLograd.addItem("Rua");// adiciona a segunda opção
        cmbLograd.addItem("Avenida");// adiciona a terceira opção
        cmbLograd.addItem("Praça");// adiciona a quarta opção
        cmbLograd.setSize(60,20);// define o tamanho do campo
        cmbLograd.setLocation(105,75);// define a localização do campo
        this.add(cmbLograd);// adiciona o Campo

        txtLogradouro = new JTextField();//inicialização do campo do logradouro
        txtLogradouro.setSize(285,20);// define o tamanho do campo
        txtLogradouro.setLocation(170,75);// define a localização do campo
        this.add(txtLogradouro);// adiciona o Campo
        
        
        lblNumero = new JLabel ("Número"); // define a label do numero
        lblNumero.setSize(100, 30);// define o tamanho do label
        lblNumero.setLocation(10, 100);// define a localização do label
        this.add(lblNumero);// adiciona o label

        txtNumero = new JTextField ();//inicialização do campo do numero
        txtNumero.setSize(80,20);// define o tamanho do campo
        txtNumero.setLocation(105,105);// define a localização do campo
        this.add(txtNumero);// adiciona o Campo

        lblBairro = new JLabel ("Bairro"); // define a label do bairro
        lblBairro.setSize(40,20);// define o tamanho do label
        lblBairro.setLocation(190,105);// define a localização do label
        this.add(lblBairro);// adiciona o label

        txtBairro = new JTextField ();//inicialização do campo do bairro
        txtBairro.setSize(220,20);// define o tamanho do campo
        txtBairro.setLocation(235,105);// define a localização do campo
        this.add(txtBairro);// adiciona o Campo
        
        
        lblCidade = new JLabel ("Cidade"); // define a label do cidade
        lblCidade.setSize(100, 30);// define o tamanho do label
        lblCidade.setLocation(10, 130);// define a localização do label
        this.add(lblCidade);// adiciona o label

        txtCidade = new JTextField();//inicialização do campo da cidade
        txtCidade.setSize(150, 20);// define o tamanho do campo
        txtCidade.setLocation(105, 135);// define a localização do campo
        this.add(txtCidade);// adiciona o Campo
        
        lblUF = new JLabel ("UF"); // define a label do UF
        lblUF.setSize (20,20);// define o tamanho do label
        lblUF.setLocation (260,135);// define a localização do label
        this.add(lblUF);// adiciona o label

        cmbUF = new JComboBox(); //inicialização do campo da UF
        cmbUF.addItem("  ");// Adiciona o primeira opção
        cmbUF.addItem("SP");// Adiciona o segunda opção
        cmbUF.addItem("RJ");// Adiciona o terceira opção
        cmbUF.addItem("MG");// Adiciona o quarta opção
        cmbUF.addItem("AM");// Adiciona o quinta opção
        cmbUF.setSize (50,20);// define o tamanho do campo
        cmbUF.setLocation (285,135);// define a localização do campo
        this.add(cmbUF);// adiciona o Campo
        
        lblCEP = new JLabel("CEP"); // define a label do cep
        lblCEP.setSize (40,20);// define o tamanho do label
        lblCEP.setLocation (350,135);// define a localização do label
        this.add(lblCEP);// adiciona o label

        txtCEP = new JTextField();//inicialização do campo CEP
        txtCEP.setSize (65,20);// define o tamanho do campo
        txtCEP.setLocation (390,135);// define a localização do campo
        this.add(txtCEP);// adiciona o Campo
        
        btnInserir = new JButton("Inserir");   //inicialização do butão inserir 
        btnInserir.setSize(95 , 30); //define o tamanho do botão
        btnInserir.setLocation (10 , 165); //define a localização  do Butão
        btnInserir.addActionListener(new // adiciona o comando listener
            ActionListener() // Adiciona um comando
            {
                public void actionPerformed(ActionEvent e)//adiciona uma função
                {
                    InserirRegistro(); //chama a função inserir
                }

            });
        this.add(btnInserir);
        
        btnAlterar = new JButton ("Alterar");//inicialização do butão alterar
        btnAlterar.setSize(95 , 30);//define o tamanho do botão
        btnAlterar.setLocation (105 , 165);//define a localização  do Butão
        btnAlterar.addActionListener(new // adiciona o comando listener
            ActionListener()// Adiciona um comando
            {
                public void actionPerformed(ActionEvent e)//adiciona uma função
                {
                    AlterarRegistro(); //chama a função alterar
                }

            });
        this.add(btnAlterar);

        btnExcluir = new JButton ("Excluir");//inicialização do butão excluir
        btnExcluir.setSize(95 , 30);//define o tamanho do botão
        btnExcluir.setLocation (200 , 165);//define a localização  do Butão
        btnExcluir.addActionListener(new // adiciona o comando listener
            ActionListener()// Adiciona um comando
            {
                public void actionPerformed(ActionEvent e)//adiciona uma função
                {
                    ExcluirRegistro(); //chama a função excluir
                }

            });
        this.add(btnExcluir);
        
        btnConsultar = new JButton ("Consultar");//inicialização do butão consultar
        btnConsultar.setSize(95 , 30);//define o tamanho do botão
        btnConsultar.setLocation (295 , 165);//define a localização  do Butão
        btnConsultar.addActionListener(new // adiciona o comando listener
            ActionListener()// Adiciona um comando
            {
                public void actionPerformed(ActionEvent e)//adiciona uma função
                {
                    Pesquisa(); //chama a função consultar
                }

            });
        this.add(btnConsultar);
        
        btnSair = new JButton ("Sair");//inicialização do butão sair
        btnSair.setSize(64 , 30);//define o tamanho do botão
        btnSair.setLocation (390, 165);//define a localização  do Butão
        btnConsultar.addActionListener(new // adiciona o comando listener
            ActionListener()// Adiciona um comando
            {
                public void actionPerformed(ActionEvent e)//adiciona uma função
                {
                    Finaliza(); // chamada da função que finaliza o programa
                }

            });
        this.add(btnSair);
        
        Desable(); // Solicita a desabilitação dos campos
        SetKey(""); // Localiza o ultimo registro 

    }
    
    private void Finaliza(){ //inicio da funação que finaliza o programa 
        this.dispose(); // finalização do programa
    }
    
    private void Pesquisa(){ //inicio da funação que finaliza o programa 
        ConsultaClientes CC = new ConsultaClientes(this); // Cria o objeto de pesquisa
        CC.setVisible(true); // mostra a tela de pesquisa
    }
    
    private void InserirRegistro(){ //inicio da função que insere o registro
        
        if(OpTipo == 0) { // verifica a operação realizada
            
//            txtCodigo.setEnabled  (true);

            PrevCod = txtCodigo.getText(); // acumula o codigo antirior para caso de cancelamento
            
            int Codigo; //inicia a veriavel que gera o novo codigo
            
            String Cmd = "Select codigo From Clientes Order by codigo Desc Limit 1" ; //localiza o ultimo registro
            PreparedStatement PS; // iniciaza a variavel que controla a execuçao de comandos
            try { // inicia a verificação de erro
                PS = Cnn.prepareStatement(Cmd); //envia o comando a base de dados
                ResultSet RS = PS.executeQuery(); // executga o comando solicitado

                if(RS.next()) { // verifica se houve retorno
                    Codigo = Integer.parseInt(RS.getString(1)); // captura o ultimo codigo inserido
                    txtCodigo.setText(String.format("%06d", Codigo + 1)); // cria o novo codigo
                } else { // caso não haja registros
                    txtCodigo.setText("000001"); // inicia o registro "000001"
                }
                } catch (SQLException ex) { // executa caso haja erro
                Logger.getLogger(JaneladeClientes.class.getName()).log(Level.SEVERE, null, ex); //emite uma mensagem de erro
            }
            
            Habilita(); // chamada da função que habilita os campos

            txtNome.setText(""); // limpa o campo nome
            txtLogradouro.setText("");// limpa o campo logradouro
            txtNumero.setText("");// limpa o campo numero
            txtBairro.setText("");// limpa o campo bairro
            txtCidade.setText("");// limpa o campo cidade
            txtCEP.setText("");// limpa o campo cep

            cmbLograd.setSelectedItem("Rua"); // inicializa o campo tipo do logradouro 
            cmbUF.setSelectedItem("SP"); // inicializa o campo UF

            btnInserir.setText("Gravar"); // altera o texto do botão inserir para gravar
            btnAlterar.setText("Cancelar");// altera o texto do botão alterar para cancelar

            btnExcluir.setEnabled(false); // desabilita o botão excluir
            btnConsultar.setEnabled(false);// desabilita o botão consultar
            btnSair.setEnabled(false);// desabilita o botão sair

            OpTipo = 1; // coloca o programa em inclusão
            
        } else { // Caso o programa esteja realizando uma inclusão/alteração
            
            String Cmd = ""; //inicia a variavel do comando
            
            if(OpTipo == 1) { // verifica se estamos incluindo
                Cmd = "Insert into Clientes (Codigo, Nome, TipoLog, Logradouro, Numero, Bairro, Cidade, UF, CEP) "; // criação do comando de inclusão
                Cmd += "Values (?, ?, ?, ?, ?, ?, ?, ?, ?)"; // criação do comando de inclusão
            } else { // caso estajamos alterando
                Cmd = "UpDate Clientes set Nome = ?, TipoLog = ?, Logradouro = ?, Numero = ?, "; // criação do comando de alteração
                Cmd += "Bairro = ?, Cidade = ?, UF = ?, CEP = ? where Codigo = ?";// criação do comando de alteração
            }
            
            try { // inicia a verificação de erro
                PreparedStatement PS = Cnn.prepareStatement(Cmd); // iniciaza a variavel que controla a execuçao de comandos
                
                int Pos = 1; //indica o parametro inicial
                
                if(OpTipo == 1) { // verifica se estamos incluindo 
                    PS.setString(1, txtCodigo.getText()); // informa o codigo em caso de inclusão
                    Pos++; // move para o proximo parametro
                }
                PS.setString(Pos, txtNome.getText());// informa o nome
                Pos++;// move para o proximo parametro
                PS.setString(Pos, (String)cmbLograd.getSelectedItem());// informa o Tipo do logradouro
                Pos++;// move para o proximo parametro
                PS.setString(Pos, txtLogradouro.getText());// informa o logradouro
                Pos++;// move para o proximo parametro
                PS.setString(Pos, txtNumero.getText());// informa o numero
                Pos++;// move para o proximo parametro
                PS.setString(Pos, txtBairro.getText());// informa o Bairro
                Pos++;// move para o proximo parametro
                PS.setString(Pos, txtCidade.getText());// informa a cidade
                Pos++;// move para o proximo parametro
                PS.setString(Pos, (String)cmbUF.getSelectedItem());// informa a UF
                Pos++;// move para o proximo parametro
                PS.setString(Pos, txtCEP.getText());// informa o cep
                Pos++;// move para o proximo parametro

                if(OpTipo == 2) {// verifica se estamos alterando
                    PS.setString(Pos, txtCodigo.getText()); // informa o codigo em caso de alteração
                }
                
                PS.execute(); // executa o comando 

            } catch (SQLException ex) { // executa em caso de erro
                Logger.getLogger(JaneladeClientes.class.getName()).log(Level.SEVERE, null, ex); // mensagem de erro
            }
            
            btnInserir.setText("Inserir");  // Altera a descrição do botão gravar para inserir
            btnAlterar.setText("Alterar");// Altera a descrição do botão cancelar para alterar

            btnExcluir.setEnabled(true);  // habilita o  botão excluir
            btnConsultar.setEnabled(true);// habilita o  botão consultar
            btnSair.setEnabled(true);// habilita o  botão sair

            OpTipo = 0; // retorna a solicitação de operaçao

            Desable(); // chamada da função que desabilita os campos
            
        }
        
    }

    private void AlterarRegistro(){ // inicio da função que altera registros
        
        if(OpTipo == 0) { // verifica a operação realizada
            
            Habilita(); // chnamada da fujnção que habilita os campos
            
            PrevCod = txtCodigo.getText(); // acumula o codigo antirior para caso de cancelamento

            btnInserir.setText("Gravar"); // altera o texto do botão inserir para gravar
            btnAlterar.setText("Cancelar");// altera o texto do botão alterar para cancelar

            btnExcluir.setEnabled(false); // desabilita o botão excluir
            btnConsultar.setEnabled(false);// desabilita o botão consultar
            btnSair.setEnabled(false);// desabilita o botão sair

            OpTipo = 2; // informa que estamos realizando uma alteração
            
        } else { // caso estajamos realizando uma inclusão ou alteração
            
            SetKey(PrevCod); // localiza o registro anterior a solicitação
            
            btnInserir.setText("Inserir");  // Altera a descrição do botão gravar para inserir
            btnAlterar.setText("Alterar");// Altera a descrição do botão cancelar para alterar

            btnExcluir.setEnabled(true);  // habilita o  botão excluir
            btnConsultar.setEnabled(true);// habilita o  botão consultar
            btnSair.setEnabled(true);// habilita o  botão sair

            OpTipo = 0; // retorna a solicitação de operaçao

            Desable(); // chamada da função que desabilita os campos
            
        }
        
    }
    private void ExcluirRegistro(){  // inicio da função que exclui o registro
        
        if(JOptionPane.showConfirmDialog(this, "Deseja realmente excluir cliente selecionado?", "Confirmação", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){ // cria a mensagem e verifica se foi respondida afirmativa
            
            String Cmd = ""; // cria a variavel que recebera o comando
            
            Cmd = "Delete From Clientes where Codigo = '" + txtCodigo.getText() + "'"; //cria o comando de exclusão
            
            PreparedStatement PS; // iniciaza a variavel que controla a execuçao de comandos
            try { // inicia a verificação de erro
                PS = Cnn.prepareStatement(Cmd);// iniciaza a variavel que controla a execuçao de comandos
                PS.execute(); // exedcuta o comando de exclusão
                SetKey(""); // seleciona o ultimo registro
            } catch (SQLException ex) { // se houver erro
                Logger.getLogger(JaneladeClientes.class.getName()).log(Level.SEVERE, null, ex); // mensagem de erro
            }
            
        }
        
        
    }

//    Cmd = "Insert into Clientes (Codigo, Nome, TipoLog, Logradouro, Numero, Bairro, Cidade, UF, CEP) ";
//    Cmd += "Values ('" + txtCodigo.getText() + "','" + txtNome.getText() +  ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private void Desable(){ // inicio da função que desabilita os campos

        txtCodigo.setEnabled  (false); // desabilita o codigo
        txtNome.setEnabled(false);// desabilita o nome
        txtLogradouro.setEnabled(false);// desabilita o logradouro
        txtNumero.setEnabled(false);// desabilita o numero
        txtBairro.setEnabled(false);// desabilita o Bairro
        txtCidade.setEnabled(false);// desabilita a cidade
        txtCEP.setEnabled(false);// desabilita o cep

        cmbLograd.setEnabled(false);// desabilita o tipo do ogradouro
        cmbUF.setEnabled(false);// desabilita a UF

    }
    
    private void Habilita(){// inicio da função que habilita os campos

        txtNome.setEnabled(true); // habilita o nome
        txtLogradouro.setEnabled(true);// habilita logradouro
        txtNumero.setEnabled(true);// habilita o nunmero
        txtBairro.setEnabled(true);// habilita o Bairro
        txtCidade.setEnabled(true);// habilita a cidade
        txtCEP.setEnabled(true);// habilita o cep
        cmbLograd.setEnabled(true);// habilita o tipo do logradouro
        cmbUF.setEnabled(true);// habilita a UF
    }

    public void SetKey(String Keys) { // inicio da função que localiza registros
        
        
        String Cmd; //criação da variavel que cria comandos
        
        if(Keys == "") { // verifica se foi solicitada um chave
            Cmd = "Select * From Clientes Order by Codigo Desc Limit 1"; // comando que localiza o ultimo registro
        } else { // se foi informada uma chave
            Cmd = "Select * From Clientes Where Codigo = '" + Keys + "'"; // comando que localiza um regustro especifico
        }
        
        PreparedStatement PS; //cria a variavel que controle o envio de comandos
        try { //inicia a verificação  de erro
            PS = Cnn.prepareStatement(Cmd);  //inicia a variavel que controle o envio de comandos
            ResultSet RS = PS.executeQuery(); // envia o comando e guarda o resultado
            if(RS.next()){ // verifica se retornou o registro
                    txtCodigo.setText(RS.getString(1)); //informa o codigo no campo codigo
                    txtNome.setText(RS.getString(2));//informa o nome no campo nome
                    txtLogradouro.setText(RS.getString(4));//informa o logradouro no campo logradouro
                    txtNumero.setText(RS.getString(5));//informa o numero no campo numero
                    txtBairro.setText(RS.getString(6));//informa o bairro no campo Bairro
                    txtCidade.setText(RS.getString(7));//informa a cidade no campo cidade
                    txtCEP.setText(RS.getString(9));//informa o cep no campo cep

                    cmbLograd.setSelectedItem(RS.getString(3));//informa o tipo do logradouro no campo tipo
                    cmbUF.setSelectedItem(RS.getString(8));//informa a UF no campo UF
            }
        } catch (SQLException ex) { // caso haja erro
            Logger.getLogger(JaneladeClientes.class.getName()).log(Level.SEVERE, null, ex); // mensagem de erro
        }
        
        
    }

    public List<String []> LogRegs(){ //Inicio da função que retorna os clientes
        
        String Cmd; //criação da variavel que cria comandos
        List<String []> ListDados = new ArrayList(); // criação da lista de dados

        Cmd = "Select * From Clientes Order by Nome"; // comando que localiza o ultimo registro
        PreparedStatement st; // criação da variavel de envio de comandos
        try { // inicio da verificação de problemas 
            st = Cnn.prepareStatement(Cmd);  //inicia a variavel que controle o envio de comandos
            ResultSet rs = st.executeQuery("Select * From Clientes Order by Nome");  // criação do comando SQL para retornar todos os registro

//            CallableStatement stm = Cnn.prepareCall("{call CodigosAgenda()}");
//            ResultSet rs = stm.executeQuery(); 
 
            while(rs.next()) { // Verifica se algum registro foi localizado
                ListDados.add(new String[] {rs.getString("Codigo"),rs.getString("Nome")}); // inclusão do registro no modo padrão
            }
        } catch (SQLException ex) { // inicio da verificação de erro
            Logger.getLogger(JaneladeClientes.class.getName()).log(Level.SEVERE, null, ex);  // mensagem de erro
        }
        
        return ListDados; // retorno
        
    }    

    
    
}
